package com.chegy.hrserverplus.mapper;

import com.chegy.hrserverplus.entity.PoliticsStatus;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author chegy
 * @since 2019-07-20
 */
public interface PoliticsStatusMapper extends BaseMapper<PoliticsStatus> {

}
