package com.chegy.hrserverplus.mapper;

import com.chegy.hrserverplus.entity.HrRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author chegy
 * @since 2019-07-18
 */
public interface HrRoleMapper extends BaseMapper<HrRole> {

}
