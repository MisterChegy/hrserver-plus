package com.chegy.hrserverplus.service;

import com.chegy.hrserverplus.entity.MenuRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author chegy
 * @since 2019-07-18
 */
public interface IMenuRoleService extends IService<MenuRole> {

}
