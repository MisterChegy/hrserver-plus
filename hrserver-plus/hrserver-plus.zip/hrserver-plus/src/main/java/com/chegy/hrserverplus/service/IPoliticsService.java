package com.chegy.hrserverplus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.chegy.hrserverplus.entity.PoliticsStatus;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author chegy
 * @since 2019-07-20
 */
public interface IPoliticsService extends IService<PoliticsStatus> {

}
