package com.chegy.hrserverplus.service;

import com.chegy.hrserverplus.entity.Nation;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author chegy
 * @since 2019-07-20
 */
public interface INationService extends IService<Nation> {

}
